// fn1.h�ļ�
extern int n;  

void fn1()
{
	n=30;
}